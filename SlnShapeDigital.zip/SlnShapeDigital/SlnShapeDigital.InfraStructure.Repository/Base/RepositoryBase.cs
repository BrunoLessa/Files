﻿using Microsoft.EntityFrameworkCore;
using SlnShapeDigital.Domain.Models.Base;
using SlnShapeDigital.DomainCore.Interfaces.Repositories;
using SlnShapeDigital.InfraStructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace SlnShapeDigital.InfraStructure.Repository.Base
{
    public class RepositoryBase<TEntity> : IRepositoryBase<TEntity> where TEntity : BaseEntity
    {
        private readonly DataContext _context;

        public RepositoryBase(DataContext context)
        {
            _context = context;
        }
        public virtual async Task AddAsync(TEntity obj)
        {
            try
            {
                await _context.Set<TEntity>().AddAsync(obj);
            }
            catch
            {
                throw;
            }
        }

        public virtual async Task<TEntity> GetByIdAsync(int id)
        {
            try
            {
                return await _context.Set<TEntity>().FindAsync(id);
            }
            catch
            {
                throw;
            }
        }

        public virtual async Task<IEnumerable<TEntity>> GetAllAsync()
        {
            try
            {
                return await _context.Set<TEntity>().ToListAsync();
            }
            catch
            {
                throw;
            }
        }

        public virtual async Task UpdateAsync(TEntity obj)
        {
            try
            {
                _context.Entry(obj).State = EntityState.Modified;
            }
            catch
            {
                throw;
            }
        }

        public virtual async Task RemoveAsync(TEntity obj)
        {
            try
            {
                _context.Set<TEntity>().Remove(obj);
            }
            catch
            {
                throw;
            }
        }

        public virtual void Dispose()
        {
            _context.Dispose();
        }

        public async Task<TEntity> FirstOrDefaultAsync(Expression<Func<TEntity, bool>> predicate)
        {
            try
            {
                return await _context.Set<TEntity>().FirstOrDefaultAsync(predicate);
            }
            catch
            {
                throw;
            }
        }

        public virtual async Task<IEnumerable<TEntity>> GetWhereAsync(Expression<Func<TEntity, bool>> predicate)
        {
            try
            {
                return await _context.Set<TEntity>().Where(predicate).ToListAsync();
            }
            catch
            {
                throw;
            }
        }

        public virtual async Task<int> CountAllAsync()
        {
            try
            {
                return await _context.Set<TEntity>().CountAsync();
            }
            catch
            {
                throw;
            }
        }

        public virtual async Task<int> CountWhereAsync(Expression<Func<TEntity, bool>> predicate)
        {
            try
            {
                return await _context.Set<TEntity>().CountAsync(predicate);
            }
            catch
            {
                throw;
            }
        }
    }
}