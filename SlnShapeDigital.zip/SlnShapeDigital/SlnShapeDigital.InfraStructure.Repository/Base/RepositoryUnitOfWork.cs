﻿using SlnShapeDigital.DomainCore.Interfaces.Repositories;
using SlnShapeDigital.InfraStructure.Data;
using System;
using System.Threading.Tasks;

namespace SlnShapeDigital.InfraStructure.Repository.Base
{
    public class RepositoryUnitOfWork : IRepositoryUnitOfWork, IDisposable
    {
        private readonly DataContext _context;

        public RepositoryUnitOfWork(DataContext context)
        {
            _context = context;
        }

        public async Task<bool> CommitAsync()
        {
            var changes = await _context.SaveChangesAsync();
            return changes > 0;
        }

        public async Task BeginTransactionAsync(Func<Task> action, Action onError = null)
        {
            using (var transaction = new RepositoryTransaction(await _context.Database.BeginTransactionAsync()))
            {
                try
                {
                    await action();
                    await CommitAsync();
                    await transaction.CommitAsync();
                }
                catch(Exception ex)
                {
                    await transaction.RollBackAsync();
                    throw;
                    //onError?.Invoke();
                }
            }
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}