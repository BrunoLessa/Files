﻿using Microsoft.EntityFrameworkCore.Storage;
using SlnShapeDigital.DomainCore.Interfaces.Repositories;
using System.Threading.Tasks;

namespace SlnShapeDigital.InfraStructure.Repository.Base
{
    public class RepositoryTransaction : IRepositoryTransaction
    {
        private readonly IDbContextTransaction _transaction;

        public RepositoryTransaction(IDbContextTransaction transaction)
        {
            _transaction = transaction;
        }

        public Task CommitAsync()
        {
            _transaction.Commit();
            return Task.CompletedTask;
        }

        public Task RollBackAsync()
        {
            _transaction.Rollback();
            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _transaction?.Dispose();
        }
    }
}