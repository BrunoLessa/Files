﻿using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.DomainCore.Validators.Base;

namespace SlnShapeDigital.DomainCore.Validators
{
    public class UserValidator : BaseValidator<User>
    {
        public UserValidator()
        {
        }
    }
}