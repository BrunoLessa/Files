﻿using FluentValidation;
using SlnShapeDigital.Domain.Models.Base;
using SlnShapeDigital.DomainCore.Validators.Interfaces;

namespace SlnShapeDigital.DomainCore.Validators.Base
{
    public abstract class BaseValidator<TEntity> : AbstractValidator<TEntity>, IValidatorBase<TEntity>
        where TEntity : BaseEntity
    {
    }
}