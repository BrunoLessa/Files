﻿using FluentValidation;
using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.DomainCore.Interfaces.Repositories;
using SlnShapeDigital.DomainCore.Validators.Base;
using SlnShapeDigital.DomainCore.Validators.Interfaces;
using System.Text.RegularExpressions;

namespace SlnShapeDigital.DomainCore.Validators
{
    public class VesselValidator : BaseValidator<Vessel>, IVesselValidator
    {
        private IRepositoryBase<Vessel> _repository;
        public VesselValidator(IRepositoryBase<Vessel> repository)
        {
            _repository = repository;
            Regex regEx = new Regex("^[a-zA-Z][a-zA-Z][0-9]{3}$");
            RuleFor(x => x.Code)
                .Cascade(CascadeMode.Stop)
                .NotEmpty().WithMessage("the Code is required.")
                .Matches(regEx).WithMessage("the code must be like AA999.")                
                .MaximumLength(255).WithMessage("the Code maximum length is 255.");            

            RuleFor(x => x).MustAsync(async (entity, cancellation) =>
            {
                var persistedObject = await _repository.FirstOrDefaultAsync(x => x.Code == entity.Code);
                if(persistedObject != null)
                {
                    if (persistedObject.Id == entity.Id)
                        return true;
                    return
                        false;
                }
                return persistedObject == null;
            }).WithMessage("this code already exists in the database.");
        }
    }
}