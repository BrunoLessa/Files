﻿using FluentValidation;
using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.DomainCore.Interfaces.Repositories;
using SlnShapeDigital.DomainCore.Validators.Base;

namespace SlnShapeDigital.DomainCore.Validators
{
    public class EquipmentValidator : BaseValidator<Equipment>
    {
        private IRepositoryBase<Equipment> _repository;
        public EquipmentValidator(IRepositoryBase<Equipment> repository)
        {
            _repository = repository;
            RuleFor(x => x.Code)
                .NotEmpty().WithMessage("the code is required.")
                .MaximumLength(255).WithMessage("the Code maximum length is 255.");            
            RuleFor(x => x.Name)
                .NotEmpty().WithMessage("the name is required.")
                .MaximumLength(255).WithMessage("the name maximum length is 255.");
            RuleFor(x => x.Status)
                .IsInEnum()
                .WithMessage("invalid status option.");

            RuleFor(x => x.Location)
                .NotEmpty().WithMessage("the location of the equipment is required.");
            RuleFor(x => x.Vessel)
                .NotEmpty().WithMessage("the vessel of the equipment is required.");

            RuleFor(x => x).MustAsync(async (entity, cancellation) =>
            {
                var persistedObject = await _repository.FirstOrDefaultAsync(x => x.Code == entity.Code);
                if (persistedObject != null)
                {
                    if (persistedObject.Id == entity.Id)
                        return true;
                    return
                        false;
                }
                return persistedObject == null;
            }).WithMessage("this code already exists in the database.");
        }
    }
}