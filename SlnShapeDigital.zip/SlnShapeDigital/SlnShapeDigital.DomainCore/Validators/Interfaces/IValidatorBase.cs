﻿using FluentValidation;
using SlnShapeDigital.Domain.Models.Base;

namespace SlnShapeDigital.DomainCore.Validators.Interfaces
{
    public interface IValidatorBase<TEntity>: IValidator<TEntity>
        where TEntity : BaseEntity
    {
    }
}