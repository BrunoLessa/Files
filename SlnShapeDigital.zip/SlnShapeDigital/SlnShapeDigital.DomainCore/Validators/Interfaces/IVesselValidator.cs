﻿using SlnShapeDigital.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SlnShapeDigital.DomainCore.Validators.Interfaces
{
    public interface IVesselValidator: IValidatorBase<Vessel>
    {
    }
}
