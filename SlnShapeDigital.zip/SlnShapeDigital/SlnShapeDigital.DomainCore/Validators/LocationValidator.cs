﻿using FluentValidation;
using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.DomainCore.Interfaces.Repositories;
using SlnShapeDigital.DomainCore.Validators.Base;

namespace SlnShapeDigital.DomainCore.Validators
{
    public class LocationValidator : BaseValidator<Location>
    {
        private IRepositoryBase<Location> _repository;
        public LocationValidator(IRepositoryBase<Location> repository)
        {
            _repository = repository;
            RuleFor(x => x.Description)
                .NotEmpty().WithMessage("the Description is required.")
                .MaximumLength(255).WithMessage("the Description maximum length is 255.");

            RuleFor(x => x).MustAsync(async (entity, cancellation) =>
            {
                var persistedObject = await _repository.FirstOrDefaultAsync(x => x.Description == entity.Description);
                if (persistedObject != null)
                {
                    if (persistedObject.Id == entity.Id)
                        return true;
                    return
                        false;
                }
                return persistedObject == null;
            }).WithMessage("this description already exists in the database.");
        }
    }
}