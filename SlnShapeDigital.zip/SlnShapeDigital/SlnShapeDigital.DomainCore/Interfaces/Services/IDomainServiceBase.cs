﻿using SlnShapeDigital.Domain.Models.Base;
using SlnShapeDigital.DomainCore.Validators.Base;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace SlnShapeDigital.DomainCore.Interfaces.Services
{
    public interface IDomainServiceBase<TEntity, TValidator>
           where TEntity : BaseEntity
           where TValidator : BaseValidator<TEntity>
    {
        Task AddAsync(TEntity obj);

        Task<TEntity> GetByIdAsync(int id);

        Task<IEnumerable<TEntity>> GetAllAsync();

        Task UpdateAsync(TEntity obj);

        Task RemoveAsync(TEntity obj);

        Task<TEntity> FirstOrDefaultAsync(Expression<Func<TEntity, bool>> predicate);

        Task<IEnumerable<TEntity>> GetWhereAsync(Expression<Func<TEntity, bool>> predicate);

        Task<int> CountAllAsync();

        Task<int> CountWhereAsync(Expression<Func<TEntity, bool>> predicate);
    }
}