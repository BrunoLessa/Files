﻿using System;
using System.Threading.Tasks;

namespace SlnShapeDigital.DomainCore.Interfaces.Repositories
{
    public interface IRepositoryUnitOfWork : IDisposable
    {
        Task<bool> CommitAsync();

        Task BeginTransactionAsync(Func<Task> action, Action onError = null);
    }
}