﻿using System;
using System.Threading.Tasks;

namespace SlnShapeDigital.DomainCore.Interfaces.Repositories
{
    public interface IRepositoryTransaction : IDisposable
    {
        Task CommitAsync();

        Task RollBackAsync();
    }
}