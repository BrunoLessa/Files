﻿using SlnShapeDigital.Domain.Models.Base;
using SlnShapeDigital.Domain.Utils.Notifications;
using SlnShapeDigital.DomainCore.Interfaces.Repositories;
using SlnShapeDigital.DomainCore.Interfaces.Services;
using SlnShapeDigital.DomainCore.Validators.Base;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;
using System.Threading.Tasks;

namespace SlnShapeDigital.DomainCore.Services.Base
{
    public class DomainServiceBase<TEntity, TValidator> : IDomainServiceBase<TEntity, TValidator>
        where TEntity : BaseEntity
        where TValidator : BaseValidator<TEntity>
    {
        private readonly IRepositoryBase<TEntity> _repository;
        private readonly NotificationContext _notificationContext;

        public DomainServiceBase(
            IRepositoryBase<TEntity> repository,
            NotificationContext notificationContext)
        {
            _repository = repository;
            _notificationContext = notificationContext;
        }

        public virtual async Task AddAsync(TEntity obj)
        {
            ValidateEntity(obj);
            if (obj.Invalid)
                _notificationContext.AddNotifications(obj.ValidationResult);
            else
                await _repository.AddAsync(obj);
        }

        public virtual async Task<TEntity> GetByIdAsync(int id)
        {
            return await _repository.GetByIdAsync(id);
        }

        public virtual async Task<IEnumerable<TEntity>> GetAllAsync()
        {
            return await _repository.GetAllAsync();
        }

        public virtual async Task UpdateAsync(TEntity obj)
        {
            ValidateEntity(obj);
            
            if (obj.Invalid)
                _notificationContext.AddNotifications(obj.ValidationResult);
            else
                await _repository.UpdateAsync(obj);
        }

        public virtual async Task RemoveAsync(TEntity obj)
        {
            await _repository.RemoveAsync(obj);
        }

        public virtual async Task<TEntity> FirstOrDefaultAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await _repository.FirstOrDefaultAsync(predicate);
        }

        public virtual async Task<IEnumerable<TEntity>> GetWhereAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await _repository.GetWhereAsync(predicate);
        }

        public virtual async Task<int> CountAllAsync()
        {
            return await _repository.CountAllAsync();
        }

        public virtual async Task<int> CountWhereAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await _repository.CountWhereAsync(predicate);
        }
        private void ValidateEntity(TEntity obj)
        {
            ConstructorInfo publicConstructor = typeof(TValidator).GetConstructor(BindingFlags.Instance | BindingFlags.Public, null, new[] { typeof(IRepositoryBase<TEntity>) }, null);

            if (publicConstructor != null)
                obj.Validate(obj, (TValidator)Activator.CreateInstance(typeof(TValidator), _repository));
            else
                obj.Validate(obj, Activator.CreateInstance<TValidator>());
            
        }
    }
}
