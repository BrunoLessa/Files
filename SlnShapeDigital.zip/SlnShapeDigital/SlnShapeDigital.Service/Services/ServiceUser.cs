﻿using AutoMapper;
using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.Domain.Utils.Notifications;
using SlnShapeDigital.DomainCore.Interfaces.Repositories;
using SlnShapeDigital.DomainCore.Interfaces.Services;
using SlnShapeDigital.DomainCore.Validators;
using SlnShapeDigital.Service.DTO.DTO;
using SlnShapeDigital.Service.Interfaces.Services;
using System;
using System.Threading.Tasks;

namespace SlnShapeDigital.Service.Services
{
    public class ServiceUser : ServiceBase<User, UserDTO, UserEntranceDTO, UserValidator>, IServiceUser
    {
        public ServiceUser(IDomainServiceBase<User, UserValidator> domain, IMapper mapper, IRepositoryUnitOfWork unitOfWork, NotificationContext notificationContext) : base(domain, mapper, unitOfWork, notificationContext)
        {
        }

        public async Task<UserDTO> GetForLogin(UserEntranceDTO user)
        {
            if (user == null || user.Login != "test" || user.PassWord != "test")
                return await Task.Run(() => (new UserDTO()));

            return await Task.Run(() => (
                 new UserDTO
                 {
                     Id = 1,
                     Nome = "Test User",
                     Login = "testuser",
                     RegistrationDate = DateTime.Now,
                     Ativo = true,
                     Role = Domain.Enuns.EnumRoles.Admin
                 }));
        }
    }
}