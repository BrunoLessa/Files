﻿using AutoMapper;
using SlnShapeDigital.Domain.Enuns;
using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.Domain.Utils.Notifications;
using SlnShapeDigital.Domain.Utils.ResultObjects;
using SlnShapeDigital.DomainCore.Interfaces.Repositories;
using SlnShapeDigital.DomainCore.Interfaces.Services;
using SlnShapeDigital.DomainCore.Validators;
using SlnShapeDigital.Service.DTO.DTO;
using SlnShapeDigital.Service.DTO.SearchDTO;
using SlnShapeDigital.Service.Interfaces.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SlnShapeDigital.Service.Services
{
    public class ServiceEquipment : ServiceBase<Equipment, EquipmentDTO, EquipmentEntranceDTO, EquipmentValidator>, IServiceEquipment
    {
        private readonly IDomainServiceBase<Equipment, EquipmentValidator> _domain;
        private readonly IMapper _mapper;
        private readonly IRepositoryUnitOfWork _unitOfWork;
        private readonly NotificationContext _notificationContext;
        private readonly IDomainServiceBase<Location, LocationValidator> _domainLocation;
        private readonly IDomainServiceBase<Vessel, VesselValidator> _domainVessel;

        public ServiceEquipment(
            IDomainServiceBase<Equipment, EquipmentValidator> domain,
            IMapper mapper,
            IRepositoryUnitOfWork unitOfWork,
            NotificationContext notificationContext,
            IDomainServiceBase<Location, LocationValidator> domainLocation,
            IDomainServiceBase<Vessel, VesselValidator> domainVessel) : base(domain, mapper, unitOfWork, notificationContext)
        {
            _domain = domain;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
            _notificationContext = notificationContext;
            _domainLocation = domainLocation;
            _domainVessel = domainVessel;
        }

        public override async Task<IResult<EquipmentDTO>> AddAsync(EquipmentEntranceDTO obj)
        {
            IList<string> listaDeErros = new List<string>();

            var objeto = _mapper.Map<Equipment>(obj);

            var objLocation = await _domainLocation.GetByIdAsync(obj.IdLocation);
            var objVessel = await _domainVessel.GetByIdAsync(obj.IdVessel);

            if (objLocation == null)
                listaDeErros.Add("the location was not found.");

            if (objVessel == null)
                listaDeErros.Add("the vessel was not found.");

            if(listaDeErros.Count > 0)
                return FactoryResult.Criar(_mapper.Map<EquipmentDTO>(objeto), "Record not found.", EnumResultType.UnProcessibleEntity, listaDeErros, true);

            objeto.Vessel = objVessel;
            objeto.Location = objLocation;

            await _unitOfWork.BeginTransactionAsync(async () => { await _domain.AddAsync(objeto); });
            if (_notificationContext.HasNotifications)
                return FactoryResult.Criar(_notificationContext, _mapper.Map<EquipmentDTO>(objeto));

            return FactoryResult.Criar(_mapper.Map<EquipmentDTO>(objeto), "Record created successfully.", EnumResultType.Ok);
        }

        public override async Task<IResult<EquipmentDTO>> UpdateAsync(int id, EquipmentEntranceDTO obj)
        {
            IList<string> listaDeErros = new List<string>();
            var objeto = await _domain.GetByIdAsync(id);


            var objLocation = await _domainLocation.GetByIdAsync(obj.IdLocation);
            var objVessel = await _domainVessel.GetByIdAsync(obj.IdVessel);

            if (objLocation == null)
                listaDeErros.Add("the location was not found.");

            if (objVessel == null)
                listaDeErros.Add("the vessel was not found.");

            if (objeto == null)            
                listaDeErros.Add("The specified record was not found.");

            var objetoMapeado = _mapper.Map<EquipmentEntranceDTO, Equipment>(obj, objeto);

            if (listaDeErros.Count>0)
                return FactoryResult.Criar(_mapper.Map<EquipmentDTO>(objetoMapeado), "Record not found.", EnumResultType.NotFound, listaDeErros, true);

            

            await _unitOfWork.BeginTransactionAsync(async () => { await _domain.UpdateAsync(objetoMapeado); });

            if (_notificationContext.HasNotifications)
                return FactoryResult.Criar(_notificationContext, _mapper.Map<EquipmentDTO>(objetoMapeado));
            return FactoryResult.Criar(_mapper.Map<EquipmentDTO>(objeto), "Record updated successfully.", EnumResultType.Ok);
        }

        public async Task<List<IResult<EquipmentDTO>>> InactiveEquipmentsAsync(List<int> objectIds)
        {
            IList<string> listaDeErros = new List<string>();
            List<IResult<EquipmentDTO>> returnList = new List<IResult<EquipmentDTO>>();
            List <Equipment> equipments = new List<Equipment>();

            foreach (var item in objectIds)
            {
                var equipment = await _domain.GetByIdAsync(item);
                if (equipment == null) {
                    listaDeErros.Add($"{item} was not found.");
                    returnList.Add(FactoryResult.Criar(_mapper.Map<EquipmentDTO>(equipment), "Record not found.", EnumResultType.NotFound, listaDeErros, true));
                    continue;
                }
                equipment.Status = EnumEquipmentStatus.Inactive;
                equipments.Add(equipment);
            }

            await _unitOfWork.BeginTransactionAsync(async () => {
                foreach (var item in equipments)
                {
                    await _domain.UpdateAsync(item);

                    if (_notificationContext.HasNotifications)                    
                        returnList.Add(FactoryResult.Criar(_notificationContext, _mapper.Map<EquipmentDTO>(item)));                    
                    else                    
                        returnList.Add(FactoryResult.Criar(_mapper.Map<EquipmentDTO>(item), "record deactivated successfully.", EnumResultType.Ok));                                            
                }                
            });            
            return returnList;
        }
        
        public async Task<IEnumerable<EquipmentDTO>> GetAllEquipamentByVessel(EquipmentSearchDTO filter)
        {

            var equipmentsFound = await _domain.GetWhereAsync(x =>
                (GetStringSize(filter.VesselCode) == 0 || x.Vessel.Code.Contains(filter.VesselCode)) &&
                (GetStringSize(filter.Code) == 0 || x.Code.Contains(filter.Code)) &&
                x.Status.Equals(filter.Status));                

            return _mapper.Map<IEnumerable<EquipmentDTO>>(equipmentsFound);           
        }
    }
}