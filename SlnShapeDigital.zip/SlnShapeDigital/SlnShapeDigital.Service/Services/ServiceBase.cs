﻿using AutoMapper;
using SlnShapeDigital.Domain.Models.Base;
using SlnShapeDigital.Domain.Utils.Notifications;
using SlnShapeDigital.Domain.Utils.ResultObjects;
using SlnShapeDigital.DomainCore.Interfaces.Repositories;
using SlnShapeDigital.DomainCore.Interfaces.Services;
using SlnShapeDigital.DomainCore.Validators.Base;
using SlnShapeDigital.Service.DTO.DTO.Base;
using SlnShapeDigital.Service.Interfaces.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SlnShapeDigital.Service.Services
{
    public class ServiceBase<TEntity, TEntityDTO, TEntranceEntityDTO, TValidator> : IServiceBase<TEntity, TEntityDTO, TEntranceEntityDTO, TValidator>
         where TEntity : BaseEntity
         where TEntityDTO : BaseDTO
         where TEntranceEntityDTO : BaseEntranceDTO
         where TValidator : BaseValidator<TEntity>
    {
        private readonly IDomainServiceBase<TEntity, TValidator> _domain;
        private readonly IMapper _mapper;
        private readonly IRepositoryUnitOfWork _unitOfWork;
        private readonly NotificationContext _notificationContext;

        public ServiceBase(
            IDomainServiceBase<TEntity, TValidator> domain,
            IMapper mapper,
            IRepositoryUnitOfWork unitOfWork,
            NotificationContext notificationContext)
        {
            _domain = domain;
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _notificationContext = notificationContext;
        }

        public virtual async Task<IResult<TEntityDTO>> AddAsync(TEntranceEntityDTO obj)
        {
            var objeto = _mapper.Map<TEntity>(obj);
            await _unitOfWork.BeginTransactionAsync(async () => { await _domain.AddAsync(objeto); });
            if (_notificationContext.HasNotifications)
                return FactoryResult.Criar(_notificationContext, _mapper.Map<TEntityDTO>(objeto));
            return FactoryResult.Criar(_mapper.Map<TEntityDTO>(objeto), "Record created successfully.", EnumResultType.Ok);
        }

        public virtual async Task<IEnumerable<TEntityDTO>> GetAllAsync()
        {
            var objetos = await _domain.GetAllAsync();
            return _mapper.Map<IEnumerable<TEntityDTO>>(objetos);
        }

        public virtual async Task<IResult<TEntityDTO>> GetByIdAsync(int id)
        {
            IList<string> listaDeErros = new List<string>();
            var objeto = await _domain.GetByIdAsync(id);
            if (objeto == null)
            {
                listaDeErros.Add("The specified record was not found.");
                return FactoryResult.Criar(_mapper.Map<TEntityDTO>(objeto), "Record not found.", EnumResultType.NotFound, listaDeErros, true);
            }

            return FactoryResult.Criar(_mapper.Map<TEntityDTO>(objeto), "", EnumResultType.Ok);
        }

        public virtual async Task<IResult<TEntityDTO>> RemoveAsync(int id)
        {
            IList<string> listaDeErros = new List<string>();
            var objeto = await _domain.GetByIdAsync(id);

            if (objeto == null)
            {
                listaDeErros.Add("The specified record was not found.");
                return FactoryResult.Criar(_mapper.Map<TEntityDTO>(objeto), "Record not found.", EnumResultType.NotFound, listaDeErros, true);
            }

            await _unitOfWork.BeginTransactionAsync(async () => { await _domain.RemoveAsync(objeto); });
            return FactoryResult.Criar(_mapper.Map<TEntityDTO>(objeto), "Record successfully deleted.", EnumResultType.Ok);
        }

        public virtual async Task<IResult<TEntityDTO>> UpdateAsync(int id, TEntranceEntityDTO obj)
        {
            IList<string> listaDeErros = new List<string>();
            var objeto = await _domain.GetByIdAsync(id);
            if (objeto == null)
            {
                listaDeErros.Add("The specified record was not found.");
                return FactoryResult.Criar(_mapper.Map<TEntityDTO>(obj), "Record not found.", EnumResultType.NotFound, listaDeErros, true);
            }

            var objetoMapeado = _mapper.Map<TEntranceEntityDTO, TEntity>(obj, objeto);

            await _unitOfWork.BeginTransactionAsync(async () => { await _domain.UpdateAsync(objetoMapeado); });

            if (_notificationContext.HasNotifications)
                return FactoryResult.Criar(_notificationContext, _mapper.Map<TEntityDTO>(objetoMapeado));
            return FactoryResult.Criar(_mapper.Map<TEntityDTO>(objeto), "Record updated successfully.", EnumResultType.Ok);
        }

        public virtual int GetStringSize(string str)
        {
            return string.IsNullOrEmpty(str) ? 0 : str.Length;
        }
    }
}