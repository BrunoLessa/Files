﻿using SlnShapeDigital.Domain.Models.Base;
using SlnShapeDigital.Domain.Utils.ResultObjects;
using SlnShapeDigital.DomainCore.Validators.Base;
using SlnShapeDigital.Service.DTO.DTO.Base;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SlnShapeDigital.Service.Interfaces.Services
{
    public interface IServiceBase<TEntity, TEntityDTO, TEntranceEntityDTO, TValidator>
         where TEntity : BaseEntity
         where TEntityDTO : BaseDTO
         where TEntranceEntityDTO : BaseEntranceDTO
         where TValidator : BaseValidator<TEntity>
    {
        Task<IResult<TEntityDTO>> AddAsync(TEntranceEntityDTO obj);

        Task<IResult<TEntityDTO>> GetByIdAsync(int id);

        Task<IEnumerable<TEntityDTO>> GetAllAsync();

        Task<IResult<TEntityDTO>> UpdateAsync(int id, TEntranceEntityDTO obj);

        Task<IResult<TEntityDTO>> RemoveAsync(int id);
    }
}