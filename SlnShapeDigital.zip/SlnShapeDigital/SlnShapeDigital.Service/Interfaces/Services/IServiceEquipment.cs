﻿using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.Domain.Utils.ResultObjects;
using SlnShapeDigital.DomainCore.Validators;
using SlnShapeDigital.Service.DTO.DTO;
using SlnShapeDigital.Service.DTO.SearchDTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SlnShapeDigital.Service.Interfaces.Services
{
    public interface IServiceEquipment : IServiceBase<Equipment, EquipmentDTO, EquipmentEntranceDTO, EquipmentValidator>
    {
        Task<List<IResult<EquipmentDTO>>> InactiveEquipmentsAsync(List<int> objectIds);

        Task<IEnumerable<EquipmentDTO>> GetAllEquipamentByVessel(EquipmentSearchDTO filter);
    }
}