﻿using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.DomainCore.Validators;
using SlnShapeDigital.Service.DTO.DTO;
using System.Threading.Tasks;

namespace SlnShapeDigital.Service.Interfaces.Services
{
    public interface IServiceUser : IServiceBase<User, UserDTO, UserEntranceDTO, UserValidator>
    {
        Task<UserDTO> GetForLogin(UserEntranceDTO user);
    }
}