﻿namespace SlnShapeDigital.Service.DTO.SearchDTO.Base
{
    public abstract class BaseSearchDTO
    {
    }
}