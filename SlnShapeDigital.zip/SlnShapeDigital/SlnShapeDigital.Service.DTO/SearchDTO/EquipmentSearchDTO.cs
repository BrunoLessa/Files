﻿using SlnShapeDigital.Domain.Enuns;
using SlnShapeDigital.Service.DTO.SearchDTO.Base;

namespace SlnShapeDigital.Service.DTO.SearchDTO
{
    public class EquipmentSearchDTO : BaseSearchDTO
    {
        public string Code { get; set; }
        public string VesselCode { get; set; }
        public EnumEquipmentStatus Status { get; set; }
    }
}