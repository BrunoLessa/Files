﻿using SlnShapeDigital.Service.DTO.SearchDTO.Base;

namespace SlnShapeDigital.Service.DTO.SearchDTO
{
    public class LocationSearchDTO : BaseSearchDTO
    {
        public string Description { get; set; }
    }
}