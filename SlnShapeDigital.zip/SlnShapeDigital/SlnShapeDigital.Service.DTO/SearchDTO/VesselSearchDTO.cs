﻿using SlnShapeDigital.Service.DTO.SearchDTO.Base;

namespace SlnShapeDigital.Service.DTO.SearchDTO
{
    public class VesselSearchDTO: BaseSearchDTO
    {
        public string Code { get; set; }
    }
}