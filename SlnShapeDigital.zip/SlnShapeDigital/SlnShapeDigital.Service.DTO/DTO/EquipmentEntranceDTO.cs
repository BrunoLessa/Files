﻿using SlnShapeDigital.Domain.Enuns;
using SlnShapeDigital.Service.DTO.DTO.Base;
using System.ComponentModel.DataAnnotations;

namespace SlnShapeDigital.Service.DTO.DTO
{
    public class EquipmentEntranceDTO : BaseEntranceDTO
    {        
        public string Name { get; set; }
        public string Code { get; set; }
        public int IdLocation { get; set; }
        [Required(ErrorMessage = "Por favor, informe o nome do cliente.")]
        public EnumEquipmentStatus Status { get; set; }
        public int IdVessel { get; set; }
    }
}