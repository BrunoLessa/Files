﻿using SlnShapeDigital.Service.DTO.DTO.Base;

namespace SlnShapeDigital.Service.DTO.DTO
{
    public class LocationDTO : BaseDTO
    {
        public string Description { get; set; }
    }
}