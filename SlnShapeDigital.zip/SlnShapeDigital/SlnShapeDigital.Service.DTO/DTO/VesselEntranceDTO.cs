﻿using SlnShapeDigital.Service.DTO.DTO.Base;

namespace SlnShapeDigital.Service.DTO.DTO
{
    public class VesselEntranceDTO : BaseEntranceDTO
    {
        public string Code { get; set; }
    }
}