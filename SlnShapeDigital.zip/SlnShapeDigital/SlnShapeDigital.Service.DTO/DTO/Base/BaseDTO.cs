﻿using System;

namespace SlnShapeDigital.Service.DTO.DTO.Base
{
    public abstract class BaseDTO
    {
        public int? Id { get; set; }
        public DateTime RegistrationDate { get; set; }
    }
}