﻿namespace SlnShapeDigital.Service.DTO.DTO.Base
{
    public abstract class BaseEntranceDTO
    {
    }
}