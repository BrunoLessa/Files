﻿using SlnShapeDigital.Domain.Enuns;
using SlnShapeDigital.Service.DTO.DTO.Base;

namespace SlnShapeDigital.Service.DTO.DTO
{
    public class UserDTO : BaseDTO
    {
        public string Nome { get; set; }
        public string Login { get; set; }
        public string PassWord { get; set; }
        public bool Ativo { get; set; }
        public EnumRoles Role { get; set; }
    }
}