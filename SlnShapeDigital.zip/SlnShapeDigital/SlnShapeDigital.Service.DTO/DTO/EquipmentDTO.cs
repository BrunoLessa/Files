﻿using SlnShapeDigital.Domain.Enuns;
using SlnShapeDigital.Service.DTO.DTO.Base;

namespace SlnShapeDigital.Service.DTO.DTO
{
    public class EquipmentDTO : BaseDTO
    {
        public LocationDTO Location { get; set; }
        public EnumEquipmentStatus Status { get; set; }
        public VesselDTO Vessel { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
    }
}