﻿using SlnShapeDigital.Service.DTO.DTO.Base;

namespace SlnShapeDigital.Service.DTO.DTO
{
    public class LocationEntranceDTO : BaseEntranceDTO
    {
        public string Description { get; set; }
    }
}