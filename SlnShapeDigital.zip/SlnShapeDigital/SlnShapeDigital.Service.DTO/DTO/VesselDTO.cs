﻿using SlnShapeDigital.Service.DTO.DTO.Base;

namespace SlnShapeDigital.Service.DTO.DTO
{
    public class VesselDTO : BaseDTO
    {
        public string Code { get; set; }
    }
}