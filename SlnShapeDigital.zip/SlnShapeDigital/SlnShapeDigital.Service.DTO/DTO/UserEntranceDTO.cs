﻿using SlnShapeDigital.Service.DTO.DTO.Base;

namespace SlnShapeDigital.Service.DTO.DTO
{
    public class UserEntranceDTO : BaseEntranceDTO
    {
        public string Login { get; set; }
        public string PassWord { get; set; }
    }
}