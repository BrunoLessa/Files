﻿using AutoMapper;
using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.Service.DTO.DTO;

namespace SlnShapeDigital.CrossCutting.Adapter.Mappers
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<VesselEntranceDTO, Vessel>();            
            CreateMap<VesselEntranceDTO, VesselDTO>().ReverseMap();
            CreateMap<Vessel, VesselDTO>().ReverseMap();

            CreateMap<LocationEntranceDTO, Location>();
            CreateMap<LocationEntranceDTO, LocationDTO>().ReverseMap();
            CreateMap<Location, LocationDTO>().ReverseMap();
                        

            CreateMap<EquipmentEntranceDTO, Equipment>();
            CreateMap<EquipmentEntranceDTO, EquipmentDTO>().ReverseMap();
            CreateMap<Equipment, EquipmentDTO>().ReverseMap();                                
            
            //CreateMap<Usuario, UsuarioDTO>()
            //    .AfterMap((src, dest) => dest.Id = null)
            //    .AfterMap((src, dest) => dest.PassWord = null);
        }
    }
}