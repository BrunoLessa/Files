﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using System;

namespace SlnShapeDigital.InfraStructure.Data.Utils
{
    public static class ContextExtensions
    {
        public static string GetSchemaQualifiedTableName(this DataContext context, Type entityType)
        {
            IEntityType et = context.Model.FindEntityType(entityType);
            //what to do here, entity could be both view and table!?
            //string viewName = et.GetSchemaQualifiedViewName();
            return et.GetSchemaQualifiedTableName();
        }
    }
}