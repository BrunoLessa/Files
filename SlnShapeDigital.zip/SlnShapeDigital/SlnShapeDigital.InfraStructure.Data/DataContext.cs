﻿using Microsoft.EntityFrameworkCore;
using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.InfraStructure.Data.Mappings;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SlnShapeDigital.InfraStructure.Data
{
    public class DataContext : DbContext
    {
        //public DataContext()
        //{
        //}

        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {
            Database.EnsureCreated();
        }

        public DbSet<Location> Locations { get; set; }
        public DbSet<Equipment> Equipments { get; set; }
        public DbSet<Vessel> Vessels { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseLazyLoadingProxies();            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            //classe de mapeamento (fluent api)
            modelBuilder.Entity<Location>(new LocationMap().Configure);
            modelBuilder.Entity<Equipment>(new EquipmentMap().Configure);
            modelBuilder.Entity<Vessel>(new VesselMap().Configure);
        }

        public override int SaveChanges()
        {
            foreach (var entry in ChangeTracker.Entries().Where(entry => entry.Entity.GetType().GetProperty("RegistrationDate") != null))
            {
                if (entry.State == EntityState.Added)
                {
                    entry.Property("RegistrationDate").CurrentValue = DateTime.Now;
                }

                if (entry.State == EntityState.Modified)
                {
                    entry.Property("RegistrationDate").IsModified = false;
                }
            }

            return base.SaveChanges();
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default(CancellationToken))
        {
            foreach (var entry in ChangeTracker.Entries().Where(entry => entry.Entity.GetType().GetProperty("RegistrationDate") != null))
            {
                if (entry.State == EntityState.Added)
                {
                    entry.Property("RegistrationDate").CurrentValue = DateTime.Now;
                }

                if (entry.State == EntityState.Modified)
                {
                    entry.Property("RegistrationDate").IsModified = false;
                }
            }

            return await base.SaveChangesAsync();
        }
    }
}