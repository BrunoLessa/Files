﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SlnShapeDigital.Domain.Models;

namespace SlnShapeDigital.InfraStructure.Data.Mappings
{
    public class VesselMap : BaseMap<Vessel>
    {
        public override void Configure(EntityTypeBuilder<Vessel> builder)
        {
            base.Configure(builder);
            builder.Property(x => x.Code)
                .IsRequired()
                .HasMaxLength(255);
            builder.HasMany(x => x.Equipments)
                .WithOne(y => y.Vessel);        
        }
    }
}