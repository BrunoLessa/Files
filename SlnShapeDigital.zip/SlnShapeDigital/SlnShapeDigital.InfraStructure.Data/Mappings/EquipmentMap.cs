﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SlnShapeDigital.Domain.Models;

namespace SlnShapeDigital.InfraStructure.Data.Mappings
{
    public class EquipmentMap : BaseMap<Equipment>
    {
        public override void Configure(EntityTypeBuilder<Equipment> builder)
        {
            base.Configure(builder);
            builder.Property(x => x.Code)
                .IsRequired()
                .HasMaxLength(255);
            builder.Property(x => x.Name)
                .IsRequired()
                .HasMaxLength(255);
            builder.HasOne(x => x.Location)
                .WithMany()
                .HasForeignKey(c => c.IdLocation)
                .IsRequired();
            builder.HasOne(x => x.Vessel)
                .WithMany()
                .HasForeignKey(c => c.IdVessel)
                .IsRequired();
        }
    }
}