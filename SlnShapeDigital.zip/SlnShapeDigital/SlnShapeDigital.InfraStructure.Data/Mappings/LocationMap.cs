﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SlnShapeDigital.Domain.Models;

namespace SlnShapeDigital.InfraStructure.Data.Mappings
{
    public class LocationMap : BaseMap<Location>
    {
        public override void Configure(EntityTypeBuilder<Location> builder)
        {
            base.Configure(builder);
            builder.Property(x => x.Description)
                .IsRequired()
                .HasMaxLength(255);            
        }
    }
}