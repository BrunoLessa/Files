﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SlnShapeDigital.Domain.Models.Base;

namespace SlnShapeDigital.InfraStructure.Data.Mappings
{
    public abstract class BaseMap<TEntity> : IEntityTypeConfiguration<TEntity>
        where TEntity : BaseEntity
    {
        public virtual void Configure(EntityTypeBuilder<TEntity> builder)
        {
            builder.HasKey(prop => prop.Id);
            builder.Property(prop => prop.Id).ValueGeneratedOnAdd();
            builder.Property(prop => prop.RegistrationDate)
                .HasColumnType("datetime")
                .IsRequired();
        }
    }
}