﻿using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.FileProviders;
using Microsoft.IdentityModel.Tokens;
using SlnDPC.Infra.CrossCutting.Token.Bearer;
using SlnShapeDigital.Domain.Models.Base;
using SlnShapeDigital.Domain.Utils.ResultObjects;
using SlnShapeDigital.InfraStructure.Data;
using SlnShapeDigital.Service.DTO.DTO;
using SlnShapeDigital.Service.DTO.DTO.Base;
using SlnShapeDigital.Test.Configs;
using SlnShapeDigital.Test.Utils;
using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Xunit;
// Set the orderer
[assembly: TestCollectionOrderer("SlnShapeDigital.Test.Utils.DisplayNameOrderer", "SlnShapeDigital.Test")]

// Need to turn off test parallelization so we can validate the run order
[assembly: CollectionBehavior(DisableTestParallelization = true)]

namespace SlnShapeDigital.Test.Tests
{   
    [TestCaseOrderer("SlnShapeDigital.Test.Utils.PriorityOrderer", "SlnShapeDigital.Test")]
    public abstract class TestControllerBase<TEntity, TEntityDTO, TEntityEntranceDTO, TController> : IntegrationTest<TController>
        where TEntity : BaseEntity
        where TEntityDTO : BaseDTO
        where TEntityEntranceDTO : BaseEntranceDTO
        where TController : class
    {
        private DataContext _context;

        public TestControllerBase(ApiWebApplicationFactory<TController> fixture) : base(fixture)
        {
        }

        [Fact, TestPriority(0)]
        public void ResetAllTableDataInDB()
        {
            string workingDirectory = Environment.CurrentDirectory;
            string projectParentFolder = Directory.GetParent(workingDirectory).Parent.Parent.FullName;
            var provider = new PhysicalFileProvider(projectParentFolder + "\\Configs").Root;

            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(provider)
                .AddJsonFile("TestIntegrationSettings.json")
                .Build();
            string connectionString = configuration.GetConnectionString("ShapeDigitalDb");
            DbContextOptions<DataContext> options;
            var builder = new DbContextOptionsBuilder<DataContext>();
            builder.UseSqlite(connectionString);
            options = builder.Options;
            _context = new DataContext(options);
            _context.Database.EnsureCreated();

            using (_context)
            {
                using (var command = _context.Database.GetDbConnection().CreateCommand())
                {
                    _context.Database.OpenConnection();
                    var tableName = _context.Model.FindEntityType(typeof(TEntity)).GetSchemaQualifiedTableName();
                    command.CommandText = @"Delete from  " + tableName;
                    
                    command.ExecuteNonQuery();
                    //command.CommandText = @"DBCC CHECKIDENT('[" + tableName + "]', RESEED, 0)";
                    command.CommandText = @"update SQLITE_SEQUENCE set seq = 0 where name ='" + tableName + "'";                    
                    command.ExecuteNonQuery();
                    _context.Database.CloseConnection();
                }
            }
        }

        [Fact, TestPriority(1)]
        public virtual async Task TestPostValidEntityAsync()
        {
            // Arrange
            var request = new
            {
                Url = "/" + GetClassName,
                Body = this.MakeValidEntranceEntity()
            };

            // Act
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            // Assert            
            response.IsSuccessStatusCode.Should().BeTrue();
        }

        [Fact, TestPriority(2)]
        public virtual async Task TestPostInvalidEntityAsync()
        {
            // Arrange
            var request = new
            {
                Url = "/" + GetClassName,
                Body = this.MakeInvalidValidEntranceEntity()
            };

            // Act
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            // Assert
            response.IsSuccessStatusCode.Should().BeFalse();
        }

        [Fact, TestPriority(3)]
        public virtual async Task TestGetAll()
        {
            var returnObjects = await _client.GetAndDeserialize<TEntityDTO[]>("/" + GetClassName);
            returnObjects.Should().HaveCountGreaterOrEqualTo(1);
        }

        [Fact, TestPriority(4)]
        public virtual async Task TestGetById()
        {
            var returnObjects = await _client.GetAndDeserialize<TEntityDTO[]>("/" + GetClassName);
            var lastObject = returnObjects.Length - 1;
            var returnObject = await _client.GetAndDeserialize<Result<TEntityDTO>>("/" + GetClassName + "/" + returnObjects[lastObject].Id);
            returnObject.Succeeded.Should().BeTrue();
        }

        [Fact, TestPriority(5)]
        public virtual async Task UpdateAsync()
        {
            // Arrange
            var returnObjects = await _client.GetAndDeserialize<TEntityDTO[]>("/" + GetClassName);
            var lastObject = returnObjects.Length - 1;

            var request = new
            {
                Url = "/" + GetClassName + "/" + returnObjects[lastObject].Id,
                Body = this.MakeValidEntranceEntity()
            };

            // Act
            var response = await _client.PutAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            // Assert
            response.IsSuccessStatusCode.Should().BeTrue();
        }

        [Fact, TestPriority(6)]
        public virtual async Task DeleteAsync()
        {
            // Arrange
            var returnObjects = await _client.GetAndDeserialize<TEntityDTO[]>("/" + GetClassName);
            var lastObject = returnObjects.Length - 1;

            var request = new
            {
                Url = "/" + GetClassName + "/" + returnObjects[lastObject].Id
            };

            // Act
            var response = await _client.DeleteAsync(request.Url);
            // Assert
            response.IsSuccessStatusCode.Should().BeTrue();
        }

        [Fact, TestPriority(7)]
        public virtual async Task TestPostValidEntityLastAsync()
        {
            // Arrange
            var request = new
            {
                Url = "/" + GetClassName,
                Body = this.MakeValidEntranceEntity()
            };

            // Act
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            // Assert            
            response.IsSuccessStatusCode.Should().BeTrue();
        }


        public static string GetClassName
        {
            get
            {
                Type _class = typeof(TEntity);
                return _class.Name;
            }
        }

        public static string stringRepeat(string value, int count)
        {
            return new StringBuilder(value.Length * count).Insert(0, value, count).ToString();
        }

        public static string GetToken()
        {
            //if (accessToken != null)
            //{
            //    return accessToken;
            //}

            UserDTO usuario = new UserDTO() { Nome = "test", PassWord = "test", Role = Domain.Enuns.EnumRoles.Admin};
            var token = new JwtTokenBuilder();
            string workingDirectory = Environment.CurrentDirectory;
            string projectParentFolder = Directory.GetParent(workingDirectory).Parent.Parent.FullName;
            var provider = new PhysicalFileProvider(projectParentFolder + "\\Configs").Root;

            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(provider)
                .AddJsonFile("TestIntegrationSettings.json")
                .Build();
            string _issuer = configuration.GetSection("Jwt:Issuer").Value;
            string _audience = configuration.GetSection("Jwt:Audience").Value;
            string _key = configuration.GetSection("Jwt:Key").Value;
            string _minutesToExpire = configuration.GetSection("Jwt:MinutesToExpire").Value;
            token.AddIssuer(_issuer);
            token.AddAudience(_audience);
            var securityKey = new SymmetricSecurityKey
                         (Encoding.UTF8.GetBytes(_key));
            token.AddSecurityKey(securityKey);
            token.AddSubject(usuario.Nome);
            token.AddExpiry(Convert.ToInt32(_minutesToExpire));
            token.AddClaim("role", usuario.Role.ToString());
            var tokenHandler = token.Builder();
            return tokenHandler.Value;                        
        }
        public abstract TEntityEntranceDTO MakeValidEntranceEntity();

        public abstract TEntityEntranceDTO MakeInvalidValidEntranceEntity();
    }
}