﻿using FluentAssertions;
using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.Service.DTO.DTO;
using SlnShapeDigital.Test.Configs;
using SlnShapeDigital.Test.Utils;
using SlnShapeDigital.WebApi.Controllers;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace SlnShapeDigital.Test.Tests
{
    public class TestA_VesselController : TestControllerBase<Vessel, VesselDTO, VesselEntranceDTO, WebApi.Controllers.VesselController>
    {
        public TestA_VesselController(ApiWebApplicationFactory<VesselController> fixture) : base(fixture)
        {
        }

 

        //public override void DeleteAsync()
        //{
        //    // Arrange
        //    var returnObjects = Task.Run(() => _client.GetAndDeserialize<VesselDTO[]>("/" + GetClassName)).Result;
        //    var lastObject = returnObjects.SingleOrDefault(item => item.Code == "MV010");

        //    var request = new
        //    {
        //        Url = "/" + GetClassName + "/" + lastObject.Id
        //    };
        //    // Act
        //    var response = Task.Run(() => _client.DeleteAsync(request.Url)).Result;
        //    // Assert
        //    response.IsSuccessStatusCode.Should().BeTrue();
        //}

        public override VesselEntranceDTO MakeValidEntranceEntity()
        {
            return new VesselEntranceDTO
            {
                Code = "MV010"
            };
        }

        public override VesselEntranceDTO MakeInvalidValidEntranceEntity()
        {
            return new VesselEntranceDTO
            {
                Code = stringRepeat("A", 500)
            };
        }
    }
}