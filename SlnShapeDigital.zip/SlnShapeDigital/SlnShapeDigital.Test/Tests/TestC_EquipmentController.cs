﻿using FluentAssertions;
using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.Domain.Utils.ResultObjects;
using SlnShapeDigital.Service.DTO.DTO;
using SlnShapeDigital.Service.DTO.SearchDTO;
using SlnShapeDigital.Test.Configs;
using SlnShapeDigital.Test.Utils;
using SlnShapeDigital.WebApi.Controllers;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Xunit;

namespace SlnShapeDigital.Test.Tests
{
    public class TestC_EquipmentController : TestControllerBase<Equipment, EquipmentDTO, EquipmentEntranceDTO, WebApi.Controllers.EquipmentController>
    {
        public TestC_EquipmentController(ApiWebApplicationFactory<EquipmentController> fixture) : base(fixture)
        {
        }
        [Fact, TestPriority(1)]
        public override async Task TestPostValidEntityAsync()
        {
            // Arrange
            var request = new
            {
                Url = "/" + GetClassName,
                Body = this.MakeValidEntranceEntity()
            };            
            
            _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());
            // Act
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            // Assert            
            var content = response.Content.ReadAsStringAsync();
            response.IsSuccessStatusCode.Should().BeTrue();
        }

        [Fact, TestPriority(2)]
        public override async Task TestPostInvalidEntityAsync()
        {
            // Arrange
            var request = new
            {
                Url = "/" + GetClassName,
                Body = this.MakeInvalidValidEntranceEntity()
            };
            _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());
            // Act
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            // Assert
            response.IsSuccessStatusCode.Should().BeFalse();
        }

        [Fact, TestPriority(3)]
        public override async Task TestGetAll()
        {
            _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());
            var returnObjects = await _client.GetAndDeserialize<EquipmentDTO[]>("/" + GetClassName);
            returnObjects.Should().HaveCountGreaterOrEqualTo(1);
        }

        [Fact, TestPriority(4)]
        public override async Task TestGetById()
        {
            _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());
            var returnObjects = await _client.GetAndDeserialize<EquipmentDTO[]>("/" + GetClassName);
            var lastObject = returnObjects.Length - 1;            
            var returnObject = await _client.GetAndDeserialize<Result<EquipmentDTO>>("/" + GetClassName + "/" + returnObjects[lastObject].Id);
            returnObject.Succeeded.Should().BeTrue();
        }

        [Fact, TestPriority(5)]
        public override async Task UpdateAsync()
        {
            // Arrange
            _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());
            var returnObjects = await _client.GetAndDeserialize<EquipmentDTO[]>("/" + GetClassName);
            var lastObject = returnObjects.Length - 1;

            var request = new
            {
                Url = "/" + GetClassName + "/" + returnObjects[lastObject].Id,
                Body = this.MakeValidEntranceEntity()
            };

            // Act
            var response = await _client.PutAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            // Assert
            response.IsSuccessStatusCode.Should().BeTrue();
        }

        [Fact, TestPriority(6)]
        public override async Task DeleteAsync()
        {
            // Arrange
            _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());
            var returnObjects = await _client.GetAndDeserialize<EquipmentDTO[]>("/" + GetClassName);
            var lastObject = returnObjects.Length - 1;

            var request = new
            {
                Url = "/" + GetClassName + "/" + returnObjects[lastObject].Id
            };

            // Act
            var response = await _client.DeleteAsync(request.Url);
            // Assert
            response.IsSuccessStatusCode.Should().BeTrue();
        }

        [Fact, TestPriority(7)]
        public override async Task TestPostValidEntityLastAsync()
        {
            // Arrange
            var request = new
            {
                Url = "/" + GetClassName,
                Body = this.MakeValidEntranceEntity()
            };

            // Act
            _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            // Assert            
            response.IsSuccessStatusCode.Should().BeTrue();
        }
        [Fact, TestPriority(8)]
        public async Task TestGetEquipmentsBySearching()
        {
            // Arrange
            var request = new
            {
                Url = "/" + GetClassName + "/Search",
                Body = this.MakeValidSearchEntity()
            };
            _client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetToken());
            // Act
            var response = await _client.PostAsync(request.Url, ContentHelper.GetStringContent(request.Body));
            // Assert
            var contents = await response.Content.ReadAsStringAsync();
            contents.Should().NotBe("[]");
        }

        public EquipmentSearchDTO MakeValidSearchEntity()
        {
            return new EquipmentSearchDTO
            {
                VesselCode = "MV010",
                Status = Domain.Enuns.EnumEquipmentStatus.Inactive
            };
        }

        public override EquipmentEntranceDTO MakeInvalidValidEntranceEntity()
        {
            return new EquipmentEntranceDTO
            {
                Code = stringRepeat("A", 500),
                Name = "Equipment Test",
                IdLocation = 1,
                IdVessel = 1,
                Status = Domain.Enuns.EnumEquipmentStatus.Active
            };
        }

        public override EquipmentEntranceDTO MakeValidEntranceEntity()
        {
            return new EquipmentEntranceDTO
            {
                Code = "MV001",
                Name = "Equipment Test",
                IdLocation = 2,
                IdVessel = 2,
                Status = Domain.Enuns.EnumEquipmentStatus.Inactive
            };
        }
    }
}