﻿using FluentAssertions;
using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.Service.DTO.DTO;
using SlnShapeDigital.Test.Configs;
using SlnShapeDigital.Test.Utils;
using SlnShapeDigital.WebApi.Controllers;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace SlnShapeDigital.Test.Tests
{
    public class TestB_LocationController : TestControllerBase<Location, LocationDTO, LocationEntranceDTO, WebApi.Controllers.LocationController>
    {
        public TestB_LocationController(ApiWebApplicationFactory<LocationController> fixture) : base(fixture)
        {
        }
        //public override async Task DeleteAsync()
        //{
        //    // Arrange
        //    var returnObjects = await _client.GetAndDeserialize<LocationDTO[]>("/" + GetClassName);
        //    var lastObject = returnObjects.SingleOrDefault(item => item.Description == "TesteLocation");

        //    var request = new
        //    {
        //        Url = "/" + GetClassName + "/" + lastObject.Id
        //    };
        //    // Act
        //    var response = await _client.DeleteAsync(request.Url);
        //    // Assert
        //    response.IsSuccessStatusCode.Should().BeTrue();
        //}

        public override LocationEntranceDTO MakeInvalidValidEntranceEntity()
        {
            return new LocationEntranceDTO
            {
                Description = stringRepeat("A", 500)
            };
        }

        public override LocationEntranceDTO MakeValidEntranceEntity()
        {
            return new LocationEntranceDTO
            {
                Description = "TesteLocation"
            };
        }
    }
}