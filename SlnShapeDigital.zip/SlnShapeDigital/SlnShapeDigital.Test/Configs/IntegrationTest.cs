﻿using System.Net.Http;
using Xunit;

namespace SlnShapeDigital.Test.Configs
{
    public abstract class IntegrationTest<T> : IClassFixture<ApiWebApplicationFactory<T>>
        where T :class
    {
        //private readonly Checkpoint _checkpoint = new Checkpoint
        //{
        //    SchemasToInclude = new[] {
        //    "Playground"
        //},
        //    WithReseed = true
        //};

        protected readonly ApiWebApplicationFactory<T> _factory;
        protected readonly HttpClient _client;

        public IntegrationTest(ApiWebApplicationFactory<T> fixture)
        {
            _factory = fixture;
            _client = _factory.CreateClient();

            //if needed, reset the DB
            //_checkpoint.Reset(_factory.Configuration.GetConnectionString("TestConnection")).Wait();
        }
    }
}