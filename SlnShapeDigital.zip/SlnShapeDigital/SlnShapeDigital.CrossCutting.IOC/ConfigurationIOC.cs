﻿using Autofac;
using FluentValidation;
using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.DomainCore.Interfaces.Repositories;
using SlnShapeDigital.DomainCore.Interfaces.Services;
using SlnShapeDigital.DomainCore.Services.Base;
using SlnShapeDigital.DomainCore.Validators;
using SlnShapeDigital.DomainCore.Validators.Base;
using SlnShapeDigital.DomainCore.Validators.Interfaces;
using SlnShapeDigital.InfraStructure.Repository.Base;
using SlnShapeDigital.Service.Interfaces.Services;
using SlnShapeDigital.Service.Services;

namespace SlnShapeDigital.CrossCutting.IOC
{
    public class ConfigurationIOC
    {
        public static void Load(ContainerBuilder builder)
        {
            #region Registra IOC

            #region IOC Application

            builder.RegisterGeneric(typeof(ServiceBase<,,,>)).As(typeof(IServiceBase<,,,>));
            builder.RegisterType(typeof(ServiceEquipment)).As(typeof(IServiceEquipment));
            builder.RegisterType(typeof(ServiceUser)).As(typeof(IServiceUser));
            //builder.RegisterType<ApplicationServiceUsuario>().As<IApplicationServiceUsuario>();

            #endregion IOC Application

            #region IOC Services

            builder.RegisterGeneric(typeof(DomainServiceBase<,>)).As(typeof(IDomainServiceBase<,>));
            //builder.RegisterType<DomainServiceUsuario>().As<IDomainServiceUsuario>();

            #endregion IOC Services

            #region IOC Repositorys SQL

            builder.RegisterGeneric(typeof(RepositoryBase<>)).As(typeof(IRepositoryBase<>));
            builder.RegisterType<RepositoryUnitOfWork>().As<IRepositoryUnitOfWork>();
            //builder.RegisterType<RepositoryUsuario>().As<IRepositoryUsuario>();

            #endregion IOC Repositorys SQL

            #region IOC Mapper

            //builder.RegisterGeneric(typeof(BaseValidator<>)).As(typeof(IValidatorBase<>));
            //builder.RegisterType<VesselValidator>().As<IVesselValidator>();
            //builder.RegisterType<MapperProduto>().As<IMapperProduto>();
            //builder.RegisterType<MapperUsuario>().As<IMapperUsuario>();                     

            #endregion IOC Mapper

            #endregion Registra IOC
        }
    }
}
