﻿using System.ComponentModel;
using System.Text.Json.Serialization;

namespace SlnShapeDigital.Domain.Enuns
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum EnumEquipmentStatus
    {        
        [Description("Active")]
        Active = 0,
        [Description("Inactive")]
        Inactive = 1
    }
}