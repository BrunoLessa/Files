﻿using System.ComponentModel;

namespace SlnShapeDigital.Domain.Enuns
{
    public enum EnumRoles
    {
        [Description("Admin")]
        Admin = 1,
        [Description("User")]
        User = 2,
        [Description("Reader")]
        Reader = 3
    }
}