﻿using SlnShapeDigital.Domain.Enuns;
using SlnShapeDigital.Domain.Models.Base;

namespace SlnShapeDigital.Domain.Models
{
    public class Equipment : BaseEntity
    {
        public virtual string Name { get; set; }
        public virtual string Code { get; set; }
        public virtual int IdLocation { get; set; }
        public virtual Location Location { get; set; }
        public virtual EnumEquipmentStatus Status { get; set; }
        public virtual int IdVessel { get; set; }
        public virtual Vessel Vessel { get; set; }
    }
}