﻿using SlnShapeDigital.Domain.Models.Base;

namespace SlnShapeDigital.Domain.Models
{
    public class Location : BaseEntity
    {
        public virtual string Description { get; set; }
    }
}