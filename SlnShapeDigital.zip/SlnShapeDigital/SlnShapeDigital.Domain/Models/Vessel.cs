﻿using SlnShapeDigital.Domain.Models.Base;
using System.Collections.Generic;

namespace SlnShapeDigital.Domain.Models
{
    public class Vessel : BaseEntity
    {
        public virtual string Code { get; set; }
        //navigation Property
        public virtual ICollection<Equipment> Equipments { get; set; }
    }
}