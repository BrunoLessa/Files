﻿using SlnShapeDigital.Domain.Enuns;
using SlnShapeDigital.Domain.Models.Base;

namespace SlnShapeDigital.Domain.Models
{
    public class User : BaseEntity
    {
        public string Nome { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public bool Ativo { get; set; }
        public EnumRoles Role { get; set; }
    }
}