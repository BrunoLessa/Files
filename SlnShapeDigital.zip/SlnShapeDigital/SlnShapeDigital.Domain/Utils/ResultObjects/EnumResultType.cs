﻿using System.ComponentModel;

namespace SlnShapeDigital.Domain.Utils.ResultObjects
{
    public enum EnumResultType
    {        
        Ok = 200,     
        Invalid = 400,        
        UnProcessibleEntity = 422,        
        Unauthorized = 401,        
        NotFound = 404
    }
}