﻿using System.Collections.Generic;
using System.Linq;

namespace SlnShapeDigital.Domain.Utils.ResultObjects
{
    public class Result<T> : IResult<T>
    {
        public string Title { get; set; }
        public string TraceId { get; set; }
        public EnumResultType Status { get; set; }
        public bool Succeeded => Errors.Any() ? false : true;
        public T Data { get; set; }
        public IList<string> Errors { get; set; }
    }
}