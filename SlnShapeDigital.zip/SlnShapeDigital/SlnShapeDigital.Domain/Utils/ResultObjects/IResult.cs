﻿using System.Collections.Generic;

namespace SlnShapeDigital.Domain.Utils.ResultObjects
{
    public interface IResult<T>
    {
        public string Title { get; set; }
        public string TraceId { get; set; }
        public EnumResultType Status { get; set; }
        public bool Succeeded { get; }
        public T Data { get; set; }
        public IList<string> Errors { get; set; }
    }
}