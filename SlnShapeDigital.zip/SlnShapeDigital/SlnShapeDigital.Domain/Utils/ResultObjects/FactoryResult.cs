﻿using SlnShapeDigital.Domain.Utils.Notifications;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace SlnShapeDigital.Domain.Utils.ResultObjects
{
    public static class FactoryResult
    {
        public static IResult<T> Criar<T>(NotificationContext notificacoes, T item)
        {
            return new Result<T> { Data = item, TraceId = Activity.Current?.Id, Title = "Invalid Entity", Status = EnumResultType.UnProcessibleEntity, Errors = notificacoes.Notifications.Select(x => x.Message).ToList()};
        }

        public static IResult<T> Criar<T>(NotificationContext notificacoes, T item, string titulo, EnumResultType numHttpCode)
        {
            return new Result<T> { Data = item, TraceId = Activity.Current?.Id, Title = titulo, Status = numHttpCode, Errors = notificacoes.Notifications.Select(x => x.Message).ToList() };
        }

        public static IResult<T> Criar<T>(T item, string titulo, EnumResultType numHttpCode)
        {
            return new Result<T> { Data = item, Title = titulo, Status = numHttpCode, Errors = new List<string>() };
        }

        public static IResult<T> Criar<T>(T item, string titulo, EnumResultType numHttpCode, IList<string> erros)
        {
            return new Result<T> { Data = item, TraceId = Activity.Current?.Id, Title = titulo, Status = numHttpCode, Errors = erros };
        }

        public static IResult<T> Criar<T>(T item, string titulo, EnumResultType numHttpCode, IList<string> erros, bool ehEntidadeNula)
        {
            return new Result<T> { TraceId = Activity.Current?.Id, Title = titulo, Status = numHttpCode, Errors = erros };
        }
    }
}