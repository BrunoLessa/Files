﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.DomainCore.Validators;
using SlnShapeDigital.Service.DTO.DTO;
using SlnShapeDigital.Service.DTO.SearchDTO;
using SlnShapeDigital.Service.Interfaces.Services;
using SlnShapeDigital.WebApi.Controllers.Base;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SlnShapeDigital.WebApi.Controllers
{
    [ApiController]
    [Authorize(Roles = "Admin")]
    [Route("Equipment")]
    public class EquipmentController : BaseController<Equipment, EquipmentDTO, EquipmentEntranceDTO, EquipmentValidator>
    {
        private readonly IServiceEquipment _serviceEquipment;

        public EquipmentController(IServiceBase<Equipment, EquipmentDTO, EquipmentEntranceDTO, EquipmentValidator> applicationServiceBase,
            IServiceEquipment serviceEquipment) : base(applicationServiceBase)
        {
            _serviceEquipment = serviceEquipment;
        }

        // POST api/values
        [HttpPost]
        public override async Task<ActionResult> Post([FromBody] EquipmentEntranceDTO objetoDTO)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            if (objetoDTO == null)
                return NoContent();

            var result = await _serviceEquipment.AddAsync(objetoDTO);
            return StatusCode((int)result.Status, result);
        }

        [HttpPut("{id}")]
        public override async Task<ActionResult> Put([FromBody] EquipmentEntranceDTO objetoDTO, int id)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            if (objetoDTO == null)
                return NoContent();
            var result = await _serviceEquipment.UpdateAsync(id, objetoDTO);
            return StatusCode((int)result.Status, result);
        }

        [HttpPut("InactivateEquipments")]
        public async Task<ActionResult> InactivateEquipments([FromBody] List<int> ids)
        {
            if (ids == null || ids.Count == 0)
                return BadRequest();

            var result = await _serviceEquipment.InactiveEquipmentsAsync(ids);
            return Ok(result);
        }

        [HttpPost("Search")]
        public virtual async Task<IActionResult> ObterAsync([FromBody] EquipmentSearchDTO pesquisa)
        {
            var retorno = await _serviceEquipment.GetAllEquipamentByVessel(pesquisa);

            if (retorno == null)
                return NotFound();

            return Ok(retorno);
        }
    }
}