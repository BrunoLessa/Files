﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SlnShapeDigital.WebApi.Controllers.Base
{
    public interface IBaseController
    {
    }
}
