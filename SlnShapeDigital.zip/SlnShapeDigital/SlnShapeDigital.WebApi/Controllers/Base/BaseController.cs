﻿using Microsoft.AspNetCore.Mvc;
using SlnShapeDigital.Domain.Models.Base;
using SlnShapeDigital.DomainCore.Validators.Base;
using SlnShapeDigital.Service.DTO.DTO.Base;
using SlnShapeDigital.Service.DTO.SearchDTO.Base;
using SlnShapeDigital.Service.Interfaces.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SlnShapeDigital.WebApi.Controllers.Base
{
    public class BaseController<TEntity, TEntityDTO, TEntranceEntityDTO, TValidator> : Controller, IBaseController
        where TEntity : BaseEntity
        where TEntityDTO : BaseDTO
        where TEntranceEntityDTO : BaseEntranceDTO
        where TValidator : BaseValidator<TEntity>        
    {
        private readonly IServiceBase<TEntity, TEntityDTO, TEntranceEntityDTO, TValidator> _applicationServiceBase;

        public BaseController(IServiceBase<TEntity, TEntityDTO, TEntranceEntityDTO, TValidator> applicationServiceBase)
        {
            _applicationServiceBase = applicationServiceBase;
        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TEntityDTO>>> Get()
        {
            return Ok(await _applicationServiceBase.GetAllAsync());
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public virtual async Task<ActionResult<TEntityDTO>> Get(int id)
        {
            var result = await _applicationServiceBase.GetByIdAsync(id);
            return StatusCode((int)result.Status, result);
        }

        // POST api/values
        [HttpPost]
        public virtual async Task<ActionResult> Post([FromBody] TEntranceEntityDTO objetoDTO)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            if (objetoDTO == null)
                return NoContent();

            var result = await _applicationServiceBase.AddAsync(objetoDTO);
            return StatusCode((int)result.Status, result);
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public virtual async Task<ActionResult> Put([FromBody] TEntranceEntityDTO objetoDTO, int id)
        {
            if (!ModelState.IsValid)
                return BadRequest();

            if (objetoDTO == null)
                return NoContent();
            var result = await _applicationServiceBase.UpdateAsync(id, objetoDTO);
            return StatusCode((int)result.Status, result);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public virtual async Task<ActionResult> Delete(int id)
        {
            if (id <= 0)
                return BadRequest();
            var result = await _applicationServiceBase.RemoveAsync(id);
            return StatusCode((int)result.Status, result);
        }
    }
}