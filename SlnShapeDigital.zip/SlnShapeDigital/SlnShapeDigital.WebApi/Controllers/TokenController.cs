﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using SlnDPC.Infra.CrossCutting.Token.Bearer;
using SlnShapeDigital.Service.DTO.DTO;
using SlnShapeDigital.Service.Interfaces.Services;
using System;
using System.Text;
using System.Threading.Tasks;

namespace SlnShapeDigital.WebApi.Controllers
{
    public class TokenController : Controller
    {
        private readonly IConfiguration _config;
        private readonly IServiceUser _applicationUsuario;
        private IHttpContextAccessor _httpContextAccessor;

        public TokenController(IHttpContextAccessor httpContextAccessor, IConfiguration config, IServiceUser applicationUsuario)
        {
            _config = config;
            _applicationUsuario = applicationUsuario;
            _httpContextAccessor = httpContextAccessor;
        }

        [AllowAnonymous]
        [Produces("application/json")]
        [HttpPost("api/CreateToken")]
        public async Task<IActionResult> CreateToken([FromBody] UserEntranceDTO usuarioDTO)
        {
            if (string.IsNullOrWhiteSpace(usuarioDTO.Login) || string.IsNullOrWhiteSpace(usuarioDTO.PassWord))
                return Unauthorized();

            var result = await _applicationUsuario.GetForLogin(usuarioDTO);
            if (result == null || result.Id == 0 || !result.Ativo)
                return Unauthorized();

            return Ok(new { token = GerarTokenJwt(result) });
        }

        public string GerarTokenJwt(UserDTO usuario)
        {
            var token = new JwtTokenBuilder();
            token.AddIssuer(_config["Jwt:Issuer"]);
            token.AddAudience(_config["Jwt:Audience"]);
            var securityKey = new SymmetricSecurityKey
                         (Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            token.AddSecurityKey(securityKey);
            token.AddSubject(usuario.Nome);
            token.AddExpiry(Convert.ToInt32(_config["Jwt:MinutesToExpire"]));
            token.AddClaim("role", usuario.Role.ToString());
            var tokenHandler = token.Builder();
            return tokenHandler.Value;
        }
    }
}