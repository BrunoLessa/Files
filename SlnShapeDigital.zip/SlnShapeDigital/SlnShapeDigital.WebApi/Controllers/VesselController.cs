﻿using Microsoft.AspNetCore.Mvc;
using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.DomainCore.Validators;
using SlnShapeDigital.Service.DTO.DTO;
using SlnShapeDigital.Service.Interfaces.Services;
using SlnShapeDigital.WebApi.Controllers.Base;

namespace SlnShapeDigital.WebApi.Controllers
{
    [ApiController]
    [Route("Vessel")]
    public class VesselController : BaseController<Vessel, VesselDTO, VesselEntranceDTO, VesselValidator>
    {
        public VesselController(IServiceBase<Vessel, VesselDTO, VesselEntranceDTO, VesselValidator> applicationServiceBase) : base(applicationServiceBase)
        {
        }
    }
}