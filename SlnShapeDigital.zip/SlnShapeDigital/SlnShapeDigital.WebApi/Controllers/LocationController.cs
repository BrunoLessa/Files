﻿using Microsoft.AspNetCore.Mvc;
using SlnShapeDigital.Domain.Models;
using SlnShapeDigital.DomainCore.Validators;
using SlnShapeDigital.Service.DTO.DTO;
using SlnShapeDigital.Service.Interfaces.Services;
using SlnShapeDigital.WebApi.Controllers.Base;

namespace SlnShapeDigital.WebApi.Controllers
{
    [ApiController]
    [Route("Location")]
    public class LocationController : BaseController<Location, LocationDTO, LocationEntranceDTO, LocationValidator>
    {
        public LocationController(IServiceBase<Location, LocationDTO, LocationEntranceDTO, LocationValidator> applicationServiceBase) : base(applicationServiceBase)
        {
        }
    }
}